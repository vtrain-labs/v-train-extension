﻿// vt_bookmarks.js - VT Bookmark Vault
// 付費功能：評分（👍😤）+ 收藏（❤️）+ 浮動操作面板 + 資料夾選擇器
// 依賴注入順序：必須在 vt_tracker.js 之後、content.js 之前注入
// 儲存方案：chrome.storage.local (不需要 IndexedDB 或後端)
//   - vt_ratings: { [videoId]: 'like' | 'dislike' }
//   - vt_bookmarks: [{ id, videoId, url, title, thumbnail, folderId, domain, addedAt }]
//   - vt_bm_folders: [{ id, name, parentId, order, createdAt }]

if (!window._vtBookmarksLoaded) {
    window._vtBookmarksLoaded = true;

    // ─── 全域快取 ────────────────────────────────────────────────────────
    window._vtRatingsCache = null;   // { [videoId]: 'like' | 'dislike' }
    window._vtBookmarkedSet = null;  // Set<videoId>
    const vtSyncChannel = new BroadcastChannel('vt_sync_channel');
    function notifySync() {
        vtSyncChannel.postMessage({ action: 'sync_bookmarks' });
        try { chrome.runtime.sendMessage({ action: 'VT_SYNC_BOOKMARKS' }).catch(()=>{}); } catch (e) {}
    }
    vtSyncChannel.onmessage = (e) => {
        if (e.data.action === 'sync_bookmarks') {
            _loadCache().then(() => {
                if (window._vtRefreshAllBadges) window._vtRefreshAllBadges();
                // 同步更新當前面板的狀態
                if (_currentId && window._vtBookmarkedSet) {
                    _panelRating = window._vtRatingsCache[_currentId] || null;
                    _panelBookmarked = window._vtBookmarkedSet.has(_currentId);
                    if (typeof _renderPanelState === 'function') _renderPanelState();
                }
            });
        }
    };

    // ─── 資料庫代理 (DB Proxy) ──────────────────────────────────────────────────
    // 所有 DB 操作必須透過 Background Script 進行，確保寫入擴充功能的來源 (Origin)，而非當前網站 (Host) 的來源
    const vtDBProxy = {
        get: (storeName, key) => new Promise(r => {
            const send = (retryCount = 0) => {
                try {
                    chrome.runtime.sendMessage({ action: 'VT_DB_GET', storeName, key }, res => {
                        if (chrome.runtime.lastError && retryCount < 3) return setTimeout(() => send(retryCount + 1), 300);
                        r(res || null);
                    });
                } catch (e) {
                    if (retryCount < 3) return setTimeout(() => send(retryCount + 1), 300);
                    r(null);
                }
            };
            send();
        }),
        getAll: (storeName) => new Promise(r => {
            const send = (retryCount = 0) => {
                try {
                    chrome.runtime.sendMessage({ action: 'VT_DB_GET_ALL', storeName }, res => {
                        if (chrome.runtime.lastError && retryCount < 3) return setTimeout(() => send(retryCount + 1), 300);
                        r(Array.isArray(res) ? res : []);
                    });
                } catch (e) {
                    if (retryCount < 3) return setTimeout(() => send(retryCount + 1), 300);
                    r([]);
                }
            };
            send();
        }),
        put: (storeName, obj) => new Promise(r => {
            const send = (retryCount = 0) => {
                try {
                    chrome.runtime.sendMessage({ action: 'VT_DB_PUT', storeName, obj }, res => {
                        if (chrome.runtime.lastError && retryCount < 3) return setTimeout(() => send(retryCount + 1), 300);
                        r(res || { ok: false });
                    });
                } catch (e) {
                    if (retryCount < 3) return setTimeout(() => send(retryCount + 1), 300);
                    r({ ok: false });
                }
            };
            send();
        }),
        delete: (storeName, key) => new Promise(r => {
            const send = (retryCount = 0) => {
                try {
                    chrome.runtime.sendMessage({ action: 'VT_DB_DELETE', storeName, key }, res => {
                        if (chrome.runtime.lastError && retryCount < 3) return setTimeout(() => send(retryCount + 1), 300);
                        r(res || { ok: false });
                    });
                } catch (e) {
                    if (retryCount < 3) return setTimeout(() => send(retryCount + 1), 300);
                    r({ ok: false });
                }
            };
            send();
        })
    };

    // ─── 本地拉取圖片避免 Extension 報錯 ───────────────────────────────────────────
    async function _fetchImageBase64Local(url) {
        try {
            const response = await fetch(url);
            if (!response.ok) return null;
            const blob = await response.blob();
            if (blob.type.includes('html')) return null;
            return new Promise((resolve) => {
                const reader = new FileReader();
                reader.onloadend = () => resolve({ dataUrl: reader.result, type: blob.type });
                reader.readAsDataURL(blob);
            });
        } catch (e) {
            return null; // Silent fail in console
        }
    }

    // ─── 載入快取 ────────────────────────────────────────────────────────
    async function _loadCache() {
        return new Promise(async (resolve) => {
            const ratings = await vtDBProxy.getAll('vt_ratings');
            window._vtRatingsCache = {};
            ratings.forEach(r => window._vtRatingsCache[r.videoId] = r.rating);

            const bm = await vtDBProxy.getAll('vt_bookmarks');
            window._vtBookmarkedSet = new Set(bm.map(b => b.videoId).filter(Boolean));
            chrome.storage.local.get(['vt_panel_pos', 'showInteraction', 'userLang'], data => {
                window._vtPanelPos = data.vt_panel_pos || null;
                window._vtShowInteraction = !!data.showInteraction;
                window._vtIsPro = true;
                window._vtCurrentLang = data.userLang || 'en';
                resolve();
            });
        });
    }



    function _compressImage(dataUrl) {
        return new Promise(resolve => {
            const img = new Image();
            img.onload = () => {
                const canvas = document.createElement('canvas');
                let dw = 320;
                let dh = Math.round((img.height * 320) / img.width);
                canvas.width = dw; canvas.height = dh;
                const ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0, dw, dh);
                resolve(canvas.toDataURL('image/jpeg', 0.7));
            };
            img.onerror = () => resolve(dataUrl);
            img.src = dataUrl;
        });
    }

    // ─── 評分操作 ────────────────────────────────────────────────────────
    async function _setRating(videoId, rating) {
        if (!window._vtRatingsCache) await _loadCache();
        const current = window._vtRatingsCache[videoId];
        // Toggle: 點相同評分取消
        const next = (current === rating) ? null : rating;
        if (next === null) {
            delete window._vtRatingsCache[videoId];
            await vtDBProxy.delete('vt_ratings', videoId);
        } else {
            window._vtRatingsCache[videoId] = next;
            await vtDBProxy.put('vt_ratings', { videoId, rating, timestamp: Date.now() });
        }
        if (window._vtRefreshAllBadges) window._vtRefreshAllBadges();
        notifySync();
        return next;
    }

    // ─── 書籤操作 ────────────────────────────────────────────────────────
    async function _addBookmark(videoId, url, title, thumbnail, folderId) {
        let existing = await vtDBProxy.get('vt_bookmarks', videoId);
        if (existing) {
            existing.folderId = folderId;
            existing.addedAt = Date.now();
            existing.title = title || existing.title;
        } else {
            existing = {
                id: 'bm_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7),
                videoId,
                url,
                title: title || document.title,
                thumbnail: thumbnail || '',
                folderId: folderId || null,
                domain: location.hostname,
                addedAt: Date.now()
            };
        }
        await vtDBProxy.put('vt_bookmarks', existing);
        if (window._vtBookmarkedSet) window._vtBookmarkedSet.add(videoId);
        if (window._vtRefreshAllBadges) window._vtRefreshAllBadges();
        notifySync();
        try { chrome.runtime.sendMessage({ action: "VT_TRIGGER_GC" }).catch(()=>{}); } catch(e) {}
    }

    async function _removeBookmark(videoId) {
        await vtDBProxy.delete('vt_bookmarks', videoId);
        if (window._vtBookmarkedSet) window._vtBookmarkedSet.delete(videoId);
        if (window._vtRefreshAllBadges) window._vtRefreshAllBadges();
        notifySync();
        try { chrome.runtime.sendMessage({ action: "VT_TRIGGER_GC" }).catch(()=>{}); } catch(e) {}
    }

    async function _isBookmarked(videoId) {
        if (!window._vtBookmarkedSet) await _loadCache();
        return window._vtBookmarkedSet.has(videoId);
    }

    // ─── 資料夾操作 ──────────────────────────────────────────────────────
    async function _getFolders() {
        return await vtDBProxy.getAll('vt_bm_folders');
    }

    async function _createFolder(name, parentId = null) {
        const folders = await _getFolders();
        const newF = {
            id: 'f_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7),
            name: name.trim(),
            parentId: parentId || null,
            order: folders.length,
            createdAt: Date.now()
        };
        await vtDBProxy.put('vt_bm_folders', newF);
        notifySync();
        return newF;
    }

    // ─── Pro 驗證 ────────────────────────────────────────────────────────
    async function _checkPro() {
        if (!window._vtIsPro) {
            return false;
        }
        return true;
    }

    // ─── 滑鼠移入移出觸發邏輯 ────────────────────────────────────────────
    let _panel = null;
    let _currentId = null;
    let _panelRating = null;
    let _panelBookmarked = false;

    const SVG_LIKE = `<svg viewBox="0 0 24 24" fill="white" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:1.2em;height:1.2em;vertical-align:-0.2em;display:inline-block;"><path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3"></path></svg>`;
    const SVG_DISLIKE = `<svg viewBox="0 0 24 24" fill="white" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:1.2em;height:1.2em;vertical-align:-0.2em;display:inline-block;"><path d="M10 15v4a3 3 0 0 0 3 3l4-9V2H5.72a2 2 0 0 0-2 1.7l-1.38 9a2 2 0 0 0 2 2.3zm7-13h3a2 2 0 0 1 2 2v7a2 2 0 0 1-2 2h-3"></path></svg>`;

    const _g = (k, d) => {
        const lang = window._vtCurrentLang || 'zh-TW';
        return typeof getLangText === 'function' ? getLangText(lang, k) : d;
    };
    const PANEL_BTNS = [
        { key: 'like',     html: SVG_LIKE, emoji: '👍', titleKey: 'btnLike', titleDef: '喜歡', id: 'vt-bmb-like'     },
        { key: 'dislike',  html: SVG_DISLIKE, emoji: '😤', titleKey: 'btnDislike', titleDef: '不喜歡', id: 'vt-bmb-dislike' },
        { key: 'bookmark', emoji: '❤️', titleKey: 'btnBookmark', titleDef: '收藏', id: 'vt-bmb-bm'       },
        { key: 'snapshot', emoji: '📸', titleKey: 'btnSnapshot', titleDef: '拍攝/替換封面 (自動收藏)', id: 'vt-bmb-snapshot' },
        { key: 'open',     emoji: '📚', titleKey: 'btnManage', titleDef: '書籤管理', id: 'vt-bmb-open'  },
    ];

    function _showLimitToast(target) {
        if (!target) return;
        const toast = document.createElement('div');
        const lang = window._vtCurrentLang || 'zh-TW';
        toast.textContent = typeof globalThis.getLangText === 'function' ? globalThis.getLangText(lang, 'toastUpgradePro') : '🔒 Upgrade to PRO';
        toast.style.cssText = `
            position: absolute;
            background: rgba(0, 0, 0, 0.85);
            color: #ffca28;
            padding: 6px 10px;
            border-radius: 4px;
            font-size: 13px;
            pointer-events: none;
            white-space: nowrap;
            z-index: 2147483647;
            font-family: sans-serif;
            font-weight: bold;
            opacity: 0;
            transition: opacity 0.2s;
            box-shadow: 0 2px 8px rgba(0,0,0,0.5);
        `;
        const panel = target.closest('#vt-bookmark-panel') || target;
        const rect = panel.getBoundingClientRect();
        toast.style.left = (rect.left + window.scrollX) + 'px';
        toast.style.top = (rect.top + window.scrollY - 36) + 'px';
        document.body.appendChild(toast);
        toast.offsetHeight;
        toast.style.opacity = '1';
        setTimeout(() => {
            toast.style.opacity = '0';
            setTimeout(() => toast.remove(), 200);
        }, 2500);
    }

    function _createPanel() {
        if (window !== window.top) return;
        if (_panel) {
            if (!_panel.isConnected) {
                (document.body || document.documentElement).appendChild(_panel);
            }
            return;
        }
        const p = document.createElement('div');
        p.id = 'vt-bookmark-panel';
        p.style.cssText = `
            position:fixed;bottom:82px;right:15px;display:none;
            align-items:center;gap:2px;padding:5px 8px;
            background:rgba(12,12,20,0.98);
            border-left:4px solid #e91e8c;border-radius:12px;
            z-index:2147483646;box-shadow:0 4px 20px rgba(0,0,0,0.85);
            will-change:transform;backface-visibility:hidden;transform:translateZ(0);
        `;

        const dragHandle = document.createElement('div');
        dragHandle.innerHTML = '⋮⋮';
        dragHandle.title = window.getI18nStr ? window.getI18nStr('dragHint', '拖曳移動 (點兩下恢復原位)') : '拖曳移動 (點兩下恢復原位)';
        dragHandle.style.cssText = `
            cursor:grab;color:rgba(255,255,255,0.4);font-size:14px;
            padding:0 6px;user-select:none;display:flex;align-items:center;
            transition:color 0.2s;height:100%;
        `;
        dragHandle.onmouseenter = () => {
            dragHandle.style.color = 'rgba(255,255,255,0.8)';
            dragHandle.title = window.getI18nStr ? window.getI18nStr('dragHint', '拖曳移動 (點兩下恢復原位)') : '拖曳移動 (點兩下恢復原位)';
        };
        dragHandle.onmouseleave = () => dragHandle.style.color = 'rgba(255,255,255,0.4)';
        p.appendChild(dragHandle);

        let isDragging = false;
        let startX, startY, initialLeft, initialTop;
        
        dragHandle.onmousedown = (e) => {
            if (e.button !== 0) return;
            isDragging = true;
            dragHandle.style.cursor = 'grabbing';
            window._vtPanelDragged = true;
            
            const rect = p.getBoundingClientRect();
            p.style.left = rect.left + 'px';
            p.style.top = rect.top + 'px';
            p.style.right = 'auto';
            p.style.bottom = 'auto';

            startX = e.clientX;
            startY = e.clientY;
            initialLeft = rect.left;
            initialTop = rect.top;

            document.addEventListener('mousemove', onMouseMove);
            document.addEventListener('mouseup', onMouseUp);
        };

        function onMouseMove(e) {
            if (!isDragging) return;
            let newLeft = initialLeft + (e.clientX - startX);
            let newTop = initialTop + (e.clientY - startY);
            
            const maxLeft = window.innerWidth - p.offsetWidth;
            const maxTop = window.innerHeight - p.offsetHeight;
            
            if (newLeft < 0) newLeft = 0;
            if (newLeft > maxLeft) newLeft = maxLeft;
            if (newTop < 0) newTop = 0;
            if (newTop > maxTop) newTop = maxTop;
            
            p.style.left = newLeft + 'px';
            p.style.top = newTop + 'px';
        }

        function onMouseUp() {
            isDragging = false;
            dragHandle.style.cursor = 'grab';
            document.removeEventListener('mousemove', onMouseMove);
            document.removeEventListener('mouseup', onMouseUp);
            window._vtPanelPos = { left: p.style.left, top: p.style.top };
            chrome.storage.local.set({ vt_panel_pos: window._vtPanelPos });
        }
        
        dragHandle.ondblclick = () => {
            window._vtPanelDragged = false;
            window._vtPanelPos = null;
            chrome.storage.local.remove('vt_panel_pos');
            p.style.bottom = '82px';
            p.style.right = '15px';
            p.style.top = 'auto';
            p.style.left = 'auto';
        };

        PANEL_BTNS.forEach(({ html, emoji, titleKey, titleDef, id, key }) => {
            const btn = document.createElement('button');
            btn.id = id;
            btn.title = _g(titleKey, titleDef);
            if (html) btn.innerHTML = html; else btn.textContent = emoji;
            btn.dataset.key = key;
            btn.style.cssText = `
                background:none;border:none;font-size:18px;cursor:pointer;
                padding:5px 7px;border-radius:8px;
                transition:background 0.15s,transform 0.1s;
            `;
            if (key === 'snapshot' || key === 'open') {
                btn.style.opacity = '1';
            } else {
                btn.style.opacity = '1';
                btn.style.filter = 'grayscale(0.4)';
            }
            btn.onmouseenter = () => { 
                btn.title = _g(titleKey, titleDef);
                if (!btn.dataset.active) btn.style.background = 'rgba(255,255,255,0.1)'; 
            };
            btn.onmouseleave = () => { if (!btn.dataset.active) { btn.style.background = 'none'; btn.style.transform = ''; } };
            btn.onmousedown = () => { btn.style.transform = 'scale(0.88)'; };
            btn.onmouseup = () => { btn.style.transform = 'scale(1)'; };
            p.appendChild(btn);
        });

        // 事件
        p.querySelector('#vt-bmb-like').onclick = async () => {
            if (!_currentId) return;
            _panelRating = await _setRating(_currentId, 'like');
            _renderPanelState();
        };
        p.querySelector('#vt-bmb-dislike').onclick = async () => {
            if (!_currentId) return;
            _panelRating = await _setRating(_currentId, 'dislike');
            _renderPanelState();
        };
        p.querySelector('#vt-bmb-bm').onclick = async () => {
            if (!_currentId) return;
            if (_panelBookmarked) {
                await _removeBookmark(_currentId);
                _panelBookmarked = false;
                _renderPanelState();
            } else {
                
                _showFolderPicker(_currentId);
            }
        };
        p.querySelector('#vt-bmb-open').onclick = () => {
            try { chrome.runtime.sendMessage({ action: 'VT_OPEN_BOOKMARKS' }).catch(()=>{}); } catch(e) {}
        };

        p.querySelector('#vt-bmb-snapshot').onclick = async () => {
            if (!_currentId) return;
            if (!_panelBookmarked) {
                
                await _addBookmark(_currentId, location.href, document.title, '', null);
                _panelBookmarked = true;
                _renderPanelState();
            }
            const btn = p.querySelector('#vt-bmb-snapshot');
            if (btn.textContent === '⏳') return; // 防止連點
            btn.textContent = '⏳';
            btn.style.pointerEvents = 'none';

            const handleResult = (success) => {
                btn.textContent = success ? '✅' : '❌';
                if (success) {
                    _panelBookmarked = true;
                    _renderPanelState();
                    notifySync();
                    setTimeout(() => btn.textContent = '📸', 2000);
                } else {
                    // [動態右鍵變身] 觸發右鍵選單變為強制截圖，並顯示 tooltip
                    try { chrome.runtime.sendMessage({ action: "VT_TOGGLE_CONTEXT_MENU", mode: "snapshot" }); } catch(e) {}
                    
                    let tooltip = btn.querySelector('.vt-snapshot-tooltip');
                    if (!tooltip) {
                        btn.style.position = 'relative';
                        tooltip = document.createElement('div');
                        tooltip.className = 'vt-snapshot-tooltip';
                        tooltip.style.cssText = 'position:absolute; bottom:calc(100% + 10px); right:-5px; background:#d32f2f; color:#fff; padding:8px 12px; border-radius:6px; font-size:13px; font-weight:bold; white-space:nowrap; pointer-events:none; opacity:0; transition:opacity 0.3s; z-index:2147483647; box-shadow:0 3px 10px rgba(0,0,0,0.5); letter-spacing:0.5px;';
                        tooltip.textContent = chrome.i18n.getMessage("tooltipForceSnapshot") || 'Permission restricted! Right-click within 15s ➔ Force Snapshot';
                        
                        const arrow = document.createElement('div');
                        arrow.style.cssText = 'position:absolute; top:100%; right:14px; border-width:6px; border-style:solid; border-color:#d32f2f transparent transparent transparent;';
                        tooltip.appendChild(arrow);
                        btn.appendChild(tooltip);
                    }
                    setTimeout(() => { tooltip.style.opacity = '1'; }, 10);
                    
                    setTimeout(() => {
                        if(tooltip) tooltip.style.opacity = '0';
                        setTimeout(() => { if(tooltip) tooltip.remove(); btn.textContent = '📸'; }, 300);
                    }, 14500); // 15秒左右消失
                }
                btn.style.pointerEvents = 'auto';
            };

            // [跨 Iframe 截圖修復] 如果目前是 Top Window，且自己並沒有追蹤中的影片，就廣播給所有 iframe 代為截圖
            if (window === window.top && !window.sysState?._activeEl) {
                let answered = false;
                const iframes = document.querySelectorAll('iframe');
                let pendingCount = iframes.length;
                
                const fallbackToTopWindow = () => {
                    if (answered) return;
                    answered = true;
                    // Iframe 無法處理 (通常是因為權限不足未被注入)，退回使用 Top Window 的備案 (例如抓 og:image)
                    _takeVideoSnapshot(_currentId).then(success => handleResult(success));
                };

                if (pendingCount === 0) {
                    fallbackToTopWindow();
                    return;
                }

                iframes.forEach(f => {
                    try {
                        const channel = new MessageChannel();
                        channel.port1.onmessage = (e) => {
                            if (answered) return;
                            if (e.data.success) {
                                answered = true;
                                handleResult(true);
                            } else {
                                pendingCount--;
                                if (pendingCount === 0 && !answered) fallbackToTopWindow();
                            }
                        };
                        f.contentWindow.postMessage({ type: 'VT_TAKE_SNAPSHOT', id: _currentId }, '*', [channel.port2]);
                    } catch(err) {
                        pendingCount--;
                        if (pendingCount === 0 && !answered) fallbackToTopWindow();
                    }
                });
                setTimeout(() => {
                    if (!answered) fallbackToTopWindow();
                }, 3000); // 縮短超時為 3 秒，提升體驗
            } else {
                _takeVideoSnapshot(_currentId).then(success => handleResult(success));
            }
        };

        (document.body || document.documentElement).appendChild(p);
        _panel = p;
        _startPanelSync();
    }

    let _panelSyncLoop = null;
    function _startPanelSync() {
        if (_panelSyncLoop) return;
        
        // 恢復之前的拖曳位置
        if (window._vtPanelPos) {
            window._vtPanelDragged = true;
            if (_panel) {
                _panel.style.left = window._vtPanelPos.left;
                _panel.style.top = window._vtPanelPos.top;
                _panel.style.right = 'auto';
                _panel.style.bottom = 'auto';
            }
        } else if (_panel) {
            // 預設固定在右下角
            _panel.style.bottom = '82px';
            _panel.style.right = '15px';
            _panel.style.top = 'auto';
            _panel.style.left = 'auto';
        }

        const sync = () => {
            _panelSyncLoop = requestAnimationFrame(sync);
            if (!_panel || _panel.style.display === 'none') return;
            
            // [SPA 修復] 檢查是否還在畫面上，不在就補回去
            if (!_panel.isConnected) {
                (document.body || document.documentElement).appendChild(_panel);
            }
        };
        _panelSyncLoop = requestAnimationFrame(sync);
    }

    function _renderPanelState() {
        if (!_panel) return;
        const configs = {
            like:     { active: _panelRating === 'like',      bg: 'rgba(255,215,0,0.18)',  emoji: '👍' },
            dislike:  { active: _panelRating === 'dislike',   bg: 'rgba(255,80,80,0.18)',  emoji: '😤' },
            bookmark: { active: _panelBookmarked,             bg: 'rgba(233,30,140,0.18)', emoji: '❤️' },
        };
        for (const [key, cfg] of Object.entries(configs)) {
            const btn = _panel.querySelector(`[data-key="${key}"]`);
            if (!btn) continue;
            btn.dataset.active = cfg.active ? 'true' : '';
            btn.style.filter = cfg.active ? 'none' : 'grayscale(0.4)';
            btn.style.background = cfg.active ? cfg.bg : 'none';
        }

        // 判斷是否需要顯示解鎖按鈕
        const btnUnlock = _panel.querySelector('#vt-bmb-unlock');
        if (btnUnlock) {
            const hasVideo = !!document.querySelector('video');
            const hasIframes = document.querySelectorAll('iframe').length > 0;
            if (window === window.top && !hasVideo && hasIframes) {
                btnUnlock.style.display = 'inline-block';
            } else {
                btnUnlock.style.display = 'none';
            }
        }
    }

    // ─── 資料夾選擇器 Modal ──────────────────────────────────────────────
    let _expandedFolders = new Set();

    function _showFolderPicker(videoId) {
        document.getElementById('vt-folder-picker')?.remove();

        const overlay = document.createElement('div');
        overlay.id = 'vt-folder-picker';
        overlay.style.cssText = `
            position:fixed;inset:0;background:rgba(0,0,0,0.72);
            z-index:2147483647;display:flex;align-items:center;
            justify-content:center;backdrop-filter:blur(5px);
            animation:vtFadeIn 0.18s ease;
        `;

        const modal = document.createElement('div');
        modal.style.cssText = `
            background:#13132a;border:1px solid rgba(233,30,140,0.35);
            border-radius:16px;width:360px;max-height:480px;
            display:flex;flex-direction:column;overflow:hidden;
            box-shadow:0 24px 64px rgba(0,0,0,0.85),0 0 0 1px rgba(233,30,140,0.1);
        `;

        let selectedFolderId = null;

        // Header
        const hdr = document.createElement('div');
        hdr.style.cssText = `
            padding:14px 18px;border-bottom:1px solid rgba(255,255,255,0.07);
            display:flex;justify-content:space-between;align-items:center;
        `;
        const lang = window._vtCurrentLang || 'zh-TW';
        const getLang = (k, def) => (typeof getLangText === 'function' ? getLangText(lang, k) : def);

        const htitle = document.createElement('span');
        htitle.textContent = '📁 ' + getLang('bvSelectFolder', '選擇收藏位置');
        htitle.style.cssText = 'color:#fff;font-size:15px;font-weight:700;font-family:sans-serif;';
        const xBtn = document.createElement('button');
        xBtn.textContent = '✕';
        xBtn.style.cssText = 'background:none;border:none;color:#666;cursor:pointer;font-size:17px;padding:0;line-height:1;transition:color 0.15s;';
        xBtn.onclick = () => overlay.remove();
        hdr.append(htitle, xBtn);

        // Tree
        const tree = document.createElement('div');
        tree.style.cssText = 'flex:1;overflow-y:auto;padding:8px;';

        // Add folder bar
        const addRow = document.createElement('div');
        addRow.style.cssText = 'padding:10px 16px;border-top:1px solid rgba(255,255,255,0.07);';
        const addBtn = document.createElement('button');
        addBtn.textContent = '＋ ' + getLang('bvAddRootFolder', '新增根目錄資料夾');
        addBtn.style.cssText = `
            background:rgba(233,30,140,0.08);border:1px dashed rgba(233,30,140,0.4);
            color:#e91e8c;border-radius:8px;padding:7px 14px;cursor:pointer;
            width:100%;font-family:sans-serif;font-size:13px;transition:all 0.15s;
        `;
        addBtn.onclick = async () => {
            const name = prompt(getLang('bvFolderNamePrompt', '新資料夾名稱：'));
            if (!name?.trim()) return;
            await _createFolder(name, null);
            _renderTree();
        };
        addRow.appendChild(addBtn);

        // Confirm bar
        const confirmRow = document.createElement('div');
        confirmRow.style.cssText = 'padding:12px 16px;border-top:1px solid rgba(255,255,255,0.07);display:flex;justify-content:flex-end;gap:8px;';
        
        const cancelBtn = document.createElement('button');
        cancelBtn.textContent = getLang('btnCancel', '取消');
        cancelBtn.style.cssText = 'background:none;border:1px solid rgba(255,255,255,0.15);color:#ccc;border-radius:8px;padding:7px 14px;cursor:pointer;font-family:sans-serif;font-size:13px;';
        cancelBtn.onclick = () => overlay.remove();
        
        const confirmBtn = document.createElement('button');
        confirmBtn.textContent = getLang('bvConfirmSave', '確認收藏');
        confirmBtn.style.cssText = 'background:linear-gradient(135deg,#e91e8c,#9c27b0);border:none;color:#fff;border-radius:8px;padding:7px 14px;cursor:pointer;font-family:sans-serif;font-size:13px;font-weight:bold;';
        confirmBtn.onclick = async () => {
            const url = location.href;
            const title = document.title;
            let ogImg = '';
            // [API 修復] YouTube 官方高品質縮圖 (繞過 SPA 造成的 og:image 錯誤)
            if (location.hostname.includes('youtube.com')) {
                // V-Train 內部 ID 已被全轉小寫，但 YouTube 縮圖 API 區分大小寫！
                // 必須從當前網址或 meta 中提取最原始的、區分大小寫的 YouTube ID
                let realYtId = new URLSearchParams(location.search).get('v');
                if (!realYtId && location.pathname.startsWith('/shorts/')) {
                    realYtId = location.pathname.split('/')[2];
                }
                if (!realYtId) {
                    realYtId = document.querySelector('meta[itemprop="videoId"]')?.content;
                }
                
                if (realYtId) {
                    ogImg = `https://img.youtube.com/vi/${realYtId}/mqdefault.jpg`;
                }
            } else {
                // 原本的 DOM 與 og:image 抓取邏輯 (針對其他非 SPA 網站)
                const links = Array.from(document.querySelectorAll('a')).filter(a => a.href && a.href.includes(videoId));
                for (const link of links) {
                    const container = link.closest('ytd-thumbnail, .bili-video-card, .video-card, ytd-video-renderer, ytd-rich-item-renderer') || link.parentElement;
                    if (!container) continue;
                    
                    const source = container.querySelector('source[srcset]');
                    const img = container.querySelector('img');
                    
                    if (source && source.srcset) {
                        ogImg = source.srcset.split(' ')[0];
                    } else if (img) {
                        ogImg = img.currentSrc || img.getAttribute('data-src') || img.src;
                    }
                    
                    if (ogImg && ogImg.length > 10 && !ogImg.startsWith('data:image/gif')) break;
                }

                if (!ogImg || ogImg.includes('yt3.ggpht.com')) { // 排除頻道大頭貼
                    ogImg = document.querySelector('meta[property="og:image"]')?.content ||
                            document.querySelector('meta[property="og:image:secure_url"]')?.content ||
                            document.querySelector('meta[name="twitter:image"]')?.content || '';
                }
            }

            if (!ogImg) {
                const imgs = Array.from(document.querySelectorAll('img')).filter(img => img.width > 200 && img.height > 100);
                if (imgs.length > 0) ogImg = imgs[0].src;
            }

            // [協定補全] 修復 Bilibili 等網站 og:image 使用 // 開頭導致無法下載的問題
            if (ogImg && ogImg.startsWith('//')) {
                ogImg = 'https:' + ogImg;
            }

            // [畫質解鎖] 移除 Bilibili 等網站縮圖網址後面的 @100w_100h_1c.png 壓縮裁切參數，取得高畫質原圖
            if (ogImg && ogImg.includes('@')) {
                ogImg = ogImg.split('@')[0];
            }

            // 若最終拿到的還是首頁通用 Logo (如 YouTube Logo)，則使用智能截圖備案
            if (ogImg && (ogImg.includes('youtube_logo') || ogImg.includes('logo'))) {
                _takeVideoSnapshot(videoId);
            }

            // [無痛快取機制] 擷取圖片轉換為二進位存入快取資料庫
            if (ogImg && ogImg.startsWith('http')) {
                _fetchImageBase64Local(ogImg).then(async (res) => {
                    if (res && res.dataUrl && (!res.type || !res.type.includes('html'))) {
                        const compressed = await _compressImage(res.dataUrl);
                        vtDBProxy.put('vt_thumbnails', { videoId, thumbnail: compressed }).catch(()=>{});
                    }
                });
            }

            await _addBookmark(videoId, url, title, ogImg, selectedFolderId);
            
            // [動態 CDN 自學引擎] 當下立即配對並註冊規則
            if (ogImg && ogImg.startsWith('http') && url) {
                try {
                    const imgHost = new URL(ogImg).hostname;
                    const pageOrigin = new URL(url).origin + "/";
                    try { chrome.runtime.sendMessage({ action: 'VT_SYNC_CDNS', cdnMap: { [imgHost]: pageOrigin } }).catch(()=>{}); } catch(e) {}
                } catch(e) {}
            }

            _panelBookmarked = true;
            _renderPanelState();
            
            confirmBtn.textContent = '✅ ' + getLang('bvSaved', '已收藏');
            confirmBtn.style.background = '#10b981';
            setTimeout(() => overlay.remove(), 650);
        };
        confirmRow.append(cancelBtn, confirmBtn);

        modal.append(hdr, tree, addRow, confirmRow);
        overlay.appendChild(modal);
        document.body.appendChild(overlay);

        async function _renderTree() {
            const oldScroll = tree.scrollTop;
            const folders = await _getFolders();
            tree.innerHTML = '';

            const renderItem = (label, id, depth, hasKids) => {
                const item = document.createElement('div');
                item.style.cssText = `
                    display:flex;align-items:center;padding:7px 12px 7px ${12 + depth * 20}px;
                    border-radius:8px;margin-bottom:2px;cursor:pointer;user-select:none;
                    transition:background 0.15s; position:relative;
                    ${selectedFolderId === id ? 'background:rgba(233,30,140,0.15);' : ''}
                `;
                
                item.onmouseenter = () => { if (selectedFolderId !== id) item.style.background = 'rgba(255,255,255,0.06)'; };
                item.onmouseleave = () => { if (selectedFolderId !== id) item.style.background = 'none'; };

                const chevron = document.createElement('span');
                chevron.style.cssText = `
                    display:inline-block;width:16px;color:#888;font-size:12px;
                    transition:transform 0.2s;text-align:center;
                `;
                if (hasKids) {
                    chevron.textContent = '▶';
                    if (_expandedFolders.has(id)) chevron.style.transform = 'rotate(90deg)';
                }
                
                chevron.onclick = (e) => {
                    if (hasKids) {
                        e.stopPropagation();
                        if (_expandedFolders.has(id)) _expandedFolders.delete(id);
                        else _expandedFolders.add(id);
                        _renderTree();
                    }
                };

                const lbl = document.createElement('span');
                lbl.textContent = label;
                lbl.style.cssText = 'flex:1;color:#e4e4f0;font-size:14px;font-family:sans-serif;margin-left:6px;';

                const radio = document.createElement('div');
                radio.style.cssText = `
                    width:16px;height:16px;border-radius:50%;border:2px solid ${selectedFolderId === id ? '#e91e8c' : '#555'};
                    display:flex;align-items:center;justify-content:center;
                `;
                if (selectedFolderId === id) {
                    const dot = document.createElement('div');
                    dot.style.cssText = 'width:8px;height:8px;border-radius:50%;background:#e91e8c;';
                    radio.appendChild(dot);
                }

                item.onclick = () => {
                    selectedFolderId = id;
                    _renderTree();
                };

                item.append(chevron, lbl, radio);
                tree.appendChild(item);
            };

            renderItem('📥 ' + getLang('bvUncategorizedRoot', '未分類（根目錄）'), null, 0, false);

            const renderLevel = (parentId, depth) => {
                const kids = folders.filter(f => f.parentId === parentId).sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: 'base' }));
                kids.forEach(f => {
                    const hasKids = folders.some(sub => sub.parentId === f.id);
                    renderItem('📁 ' + f.name, f.id, depth, hasKids);
                    if (hasKids && _expandedFolders.has(f.id)) {
                        renderLevel(f.id, depth + 1);
                    }
                });
            };
            renderLevel(null, 1);
            
            // 恢復滾動位置
            requestAnimationFrame(() => {
                tree.scrollTop = oldScroll;
            });
        }

        vtDBProxy.get('vt_bookmarks', videoId).then(bm => {
            selectedFolderId = bm?.folderId || null;
            _renderTree();
        }).catch(() => {
            selectedFolderId = null;
            _renderTree();
        });
    }

    // ─── 監控 Storage 變化，同步快取 + 刷新角標 ─────────────────────────
    chrome.storage.onChanged.addListener((changes) => {
        if (!chrome.runtime?.id) return;

        if (changes.showInteraction) {
            window._vtShowInteraction = !!changes.showInteraction.newValue;
            if (!window._vtShowInteraction && _panel) {
                _panel.style.display = 'none';
            }
        }

        if (changes.userLang) {
            window._vtCurrentLang = changes.userLang.newValue;
        }
    });

    // ─── 核心截圖引擎 (分離自 forceHeal 以供全域呼叫) ──────────────────
    async function _takeVideoSnapshot(targetVideoId) {
        try {
            let videoEl = window.sysState?._activeEl;
            // [Bug 修復] 在 Feed 頁面上，_activeEl 可能未更新，或是指向已被隱藏的舊預覽
            if (!videoEl || !videoEl.isConnected || videoEl.offsetWidth === 0) {
                const videos = Array.from(document.querySelectorAll('video')).filter(v => v.offsetWidth > 0 && v.videoWidth > 0);
                // 優先抓取正在播放的（Feed 頁面上只有懸停的那部會播放），否則抓面積最大的
                videoEl = videos.find(v => !v.paused) || videos.sort((a,b) => (b.offsetWidth*b.offsetHeight) - (a.offsetWidth*a.offsetHeight))[0];
            }
            if (videoEl && videoEl.tagName === 'VIDEO') {

                // [1] 嘗試使用 Canvas 直接繪製當前影片幀 (不受硬體加速黑屏影響，但可能受 CORS 阻擋)
                if (videoEl.videoWidth > 0 && videoEl.readyState >= 2) {
                    try {
                        const canvas = document.createElement('canvas');
                        let dw = 320;
                        let dh = Math.round((videoEl.videoHeight * 320) / videoEl.videoWidth);
                        canvas.width = dw; canvas.height = dh;
                        const ctx = canvas.getContext('2d');
                        ctx.drawImage(videoEl, 0, 0, dw, dh);
                        const thumbUrl = canvas.toDataURL('image/jpeg', 0.7); // 若 CORS 會在此拋出 SecurityError
                        if (thumbUrl.length > 500) {
                            vtDBProxy.put('vt_thumbnails', { videoId: targetVideoId, thumbnail: thumbUrl }).catch(()=>{});
                            return true;
                        }
                    } catch (e) { /* CORS error */ }
                }

                // [2] 取得 Iframe 偏移量，準備截取整個瀏覽器畫面 (可能遇到黑屏)
                const offset = await new Promise(resolve => {
                    if (window === window.top) return resolve({ left: 0, top: 0 });
                    try {
                        const channel = new MessageChannel();
                        channel.port1.onmessage = (e) => resolve(e.data.rect || { left: 0, top: 0 });
                        window.top.postMessage({ type: 'VT_GET_IFRAME_RECT' }, '*', [channel.port2]);
                        setTimeout(() => resolve({ left: 0, top: 0 }), 300);
                    } catch(err) { resolve({ left: 0, top: 0 }); }
                });

                return new Promise((resolve) => {
                    chrome.runtime.sendMessage({ action: "VT_CAPTURE_TAB" }, (res) => {
                        if (res && res.dataUrl) {
                            const rect = videoEl.getBoundingClientRect();
                            const img = new Image();
                            img.onload = async () => {
                                const canvas = document.createElement('canvas');
                                const ratioX = window.devicePixelRatio || 1;
                                const ratioY = window.devicePixelRatio || 1;
                                const sx = (offset.left + rect.left) * ratioX;
                                const sy = (offset.top + rect.top) * ratioY;
                                const sw = rect.width * ratioX;
                                const sh = rect.height * ratioY;
                                
                                // 檢查截圖是否為黑屏 (硬體加速導致的純黑)
                                const testCanvas = document.createElement('canvas');
                                testCanvas.width = 50; testCanvas.height = 50;
                                const testCtx = testCanvas.getContext('2d');
                                testCtx.drawImage(img, sx, sy, sw, sh, 0, 0, 50, 50);
                                const imgData = testCtx.getImageData(0, 0, 50, 50).data;
                                let pureBlackPixels = 0;
                                for (let i = 0; i < imgData.length; i += 4) {
                                    if (imgData[i] <= 2 && imgData[i+1] <= 2 && imgData[i+2] <= 2) pureBlackPixels++;
                                }
                                
                                // 如果超過 98% 是純黑色 (2450/2500)，視為硬體加速黑屏，直接報錯
                                if (pureBlackPixels > 2450) {
                                    console.error('[VT] Hardware acceleration black screen detected.');
                                    resolve(false);
                                    return;
                                }

                                let dw = rect.width;
                                let dh = rect.height;
                                if (dw > 320) { dh = Math.round((dh * 320) / dw); dw = 320; }
                                canvas.width = dw; canvas.height = dh;
                                const ctx = canvas.getContext('2d');
                                ctx.drawImage(img, sx, sy, sw, sh, 0, 0, dw, dh);
                                const thumbUrl = canvas.toDataURL('image/jpeg', 0.7);
                                
                                if (thumbUrl.length > 500) {
                                    vtDBProxy.put('vt_thumbnails', { videoId: targetVideoId, thumbnail: thumbUrl }).catch(()=>{});
                                    resolve(true); 
                                } else {
                                    console.error('[VT] Canvas generated empty image (length: ' + thumbUrl.length + '). dw=' + dw + ', dh=' + dh);
                                    resolve(false);
                                }
                            };
                            img.onerror = () => {
                                console.error('[VT] Image failed to load dataUrl');
                                resolve(false);
                            };
                            img.src = res.dataUrl;
                        } else {
                            console.error('[VT] captureVisibleTab failed:', res?.error || 'Unknown error');
                            resolve(false);
                        }
                    });
                });
            }
        } catch (e) {
            console.error('[VT] Snapshot Error:', e);
        }
        
        return false;
    }

    // ─── 公開 API（供 vt_tracker.js 呼叫）────────────────────────────────
    window.vtBookmarkPanel = {
        async setVideo(videoId) {
            if (!videoId || window._vtShowInteraction === false) {
                if (_panel) _panel.style.display = 'none';
                _currentId = null;
                return;
            }
            // [SPA 修復] 檢查面板是否被框架意外移除，如果移除則必須強制重繪
            const isDetached = _panel && !_panel.isConnected;
            
            if (_currentId === videoId && !isDetached) return; // 沒變化且還在 DOM 上，不重繪
            _currentId = videoId;

            if (!window._vtRatingsCache) await _loadCache();
            _panelRating = window._vtRatingsCache[videoId] || null;
            _panelBookmarked = window._vtBookmarkedSet?.has(videoId) || false;

            // [自癒機制 Self-Healing] 如果此影片已在書籤庫中，於背景靜默重新抓取縮圖並寫入快取庫。
            // 加入溫和的重試機制，最多 3 次，避免被當作 DDoS 攻擊，同時能繞過廣告延遲。
            if (_panelBookmarked) {
                vtDBProxy.get('vt_thumbnails', videoId).then(existingThumb => {
                    // [Bug 修復] 如果資料庫裡已經有一張正常的縮圖，就「絕對不要」發動自癒機制去覆蓋它
                    if (existingThumb && existingThumb.thumbnail && existingThumb.thumbnail.length > 500) {
                        return; 
                    }

                    const _heal = (attempt = 1) => {
                        if (attempt > 3) return; // 最多嘗試 3 次
                        setTimeout(() => {
                            if (_currentId !== videoId) return; // [SPA 保護] 避免在延遲期間用戶切換了影片，導致張冠李戴
                            let ogImg = document.querySelector('meta[property="og:image"]')?.content ||
                                        document.querySelector('meta[property="og:image:secure_url"]')?.content ||
                                        document.querySelector('meta[name="twitter:image"]')?.content || '';
                            if (ogImg && ogImg.startsWith('//')) {
                                ogImg = 'https:' + ogImg;
                            }

                            // [畫質解鎖] 移除 Bilibili 等網站縮圖網址後面的 @100w_100h_1c.png 壓縮裁切參數，取得高畫質原圖
                            if (ogImg && ogImg.includes('@')) {
                                ogImg = ogImg.split('@')[0];
                            }
                            
                            if (ogImg && ogImg.startsWith('http')) {
                                _fetchImageBase64Local(ogImg).then(async (res) => {
                                    if (res && res.dataUrl && (!res.type || !res.type.includes('html'))) {
                                        const dataUrl = await _compressImage(res.dataUrl);
                                        vtDBProxy.put('vt_thumbnails', { videoId, thumbnail: dataUrl }).catch(()=>{});
                                        notifySync(); 
                                    } else {
                                        if (await _takeVideoSnapshot(videoId)) { notifySync(); return; }
                                        _heal(attempt + 1); 
                                    }
                                });
                            } else {
                                // [Iframe 跨域修復] 在 iframe 中找不到 og:image 時，改請求 Top Window 的 og:image
                                if (window !== window.top && chrome.runtime?.id) {
                                    chrome.runtime.sendMessage({ action: "VT_GET_TOP_OG_IMAGE" }, async (res) => {
                                        if (res && res.ogImg) {
                                            _fetchImageBase64Local(res.ogImg).then(async (imgRes) => {
                                                if (imgRes && imgRes.dataUrl && (!imgRes.type || !imgRes.type.includes('html'))) {
                                                    const compressed = await _compressImage(imgRes.dataUrl);
                                                    vtDBProxy.put('vt_thumbnails', { videoId, thumbnail: compressed }).catch(()=>{});
                                                    notifySync();
                                                    return;
                                                } else {
                                                    _takeVideoSnapshotFallback();
                                                }
                                            });
                                        } else {
                                            _takeVideoSnapshotFallback();
                                        }
                                    });
                                } else {
                                    _takeVideoSnapshotFallback();
                                }
                                
                                function _takeVideoSnapshotFallback() {
                                    _takeVideoSnapshot(videoId).then(success => {
                                        if (success) {
                                            notifySync();
                                        } else {
                                            _heal(attempt + 1);
                                        }
                                    });
                                }
                            }
                        }, attempt === 1 ? 300 : 3000 * (attempt - 1)); // 第一次 0.3 秒，第二次 3 秒，第三次 6 秒
                    };
                    _heal();
                }); // Close vtDBProxy.get
            }

            _createPanel();
            if (_panel) { _panel.style.display = document.fullscreenElement ? 'none' : 'flex'; _renderPanelState(); }
        },
        hide() {
            if (_panel) _panel.style.display = 'none';
            _currentId = null;
        },
        async loadCache() { await _loadCache(); },
        takeSnapshot: _takeVideoSnapshot // Expose for cross-frame calls
    };

    document.addEventListener('fullscreenchange', () => {
        if (_panel && _currentId && window._vtShowInteraction !== false) {
            _panel.style.display = document.fullscreenElement ? 'none' : 'flex';
        }
    });

    // [跨 Iframe 截圖修復] 聽取來自上層 Window 的截圖請求，並遞迴向下傳遞
    window.addEventListener('message', async (e) => {
        if (e.data && e.data.type === 'VT_TAKE_SNAPSHOT' && e.ports && e.ports[0]) {
            const port = e.ports[0];
            const targetId = e.data.id;
            const videoEl = window.sysState?._activeEl;
            
            // 只有當這個 iframe 真的有追蹤中的影片時才嘗試截圖
            if (videoEl && videoEl.tagName === 'VIDEO') {
                const success = await _takeVideoSnapshot(targetId);
                if (port) port.postMessage({ success });
            } else {
                // 如果找不到，則繼續向下層 iframe 廣播
                const frames = document.querySelectorAll('iframe');
                if (frames.length === 0) {
                    if (port) port.postMessage({ success: false });
                    return;
                }
                
                let resolved = false;
                let pending = frames.length;
                frames.forEach(f => {
                    try {
                        const channel = new MessageChannel();
                        channel.port1.onmessage = (res) => {
                            if (res.data && res.data.success) {
                                if (!resolved) { resolved = true; if(port) port.postMessage({ success: true }); }
                            } else {
                                pending--;
                                if (pending <= 0 && !resolved) { resolved = true; if(port) port.postMessage({ success: false }); }
                            }
                        };
                        f.contentWindow.postMessage({ type: 'VT_TAKE_SNAPSHOT', id: targetId }, '*', [channel.port2]);
                    } catch(err) {
                        pending--;
                        if (pending <= 0 && !resolved) { resolved = true; if(port) port.postMessage({ success: false }); }
                    }
                });
            }
        }
    });

    // 監聽來自背景腳本的物理截圖請求 (取得 activeTab 後重試)
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === "VT_RETRY_SNAPSHOT") {
            const btn = document.getElementById('vt-bmb-snapshot');
            if (btn) {
                // 為了避免硬體加速黑屏，套用微小的濾鏡來強制重新繪製 (破壞 Overlay)
                let videoEl = window.sysState?._activeEl;
                if (!videoEl || !videoEl.isConnected || videoEl.offsetWidth === 0) {
                    const videos = Array.from(document.querySelectorAll('video')).filter(v => v.offsetWidth > 0 && v.videoWidth > 0);
                    videoEl = videos.find(v => !v.paused) || videos.sort((a,b) => (b.offsetWidth*b.offsetHeight) - (a.offsetWidth*a.offsetHeight))[0];
                }
                let originalFilter = '';
                if (videoEl) {
                    originalFilter = videoEl.style.filter || '';
                    videoEl.style.filter = originalFilter ? originalFilter + ' contrast(1.001)' : 'contrast(1.001)';
                }
                
                // 等待 100ms 讓瀏覽器重新繪製，然後點擊截圖按鈕
                setTimeout(() => {
                    btn.click();
                    // 截圖後恢復濾鏡
                    setTimeout(() => {
                        if (videoEl) videoEl.style.filter = originalFilter;
                    }, 500);
                }, 100);
            }
        }
    });

    // 啟動時預載入快取
    _loadCache();
}

